# Omnicomm Alliance KZ — CRM мониторинга транспорта

Полный архив проекта CRM: рабочий backend, пакет адаптации на базе LiftPlatform,
UI-прототипы и проектная документация.

## Состав
```
crm-backend/            Рабочий backend (Node.js + Express + SQLite), 30 эндпоинтов, 28 тестов
liftplatform-omnicomm/  Адаптация на базе LiftPlatform (Next.js): 13 миграций, 18 API-роутов, UI, интеграции
ui/                     HTML-прототипы: dashboard (макет заказчика), prototype (кликабельный), roadmap
docs/                   Документы: анализ потребности, техпроект, gap-анализы, рабочий документ разработки
```

## Быстрый старт (рабочий backend)
```bash
cd crm-backend
npm install
npm run seed     # демо-данные
npm start        # API на http://localhost:3000
npm run smoke    # 28 проверок (сквозной поток продажа → наряд → Акт ТО → биллинг)
```
Демо-доступы (пароль demo1234): admin@ / manager@ / support@ / installer@ / boss@omnicomm.kz

## UI
Откройте в браузере:
- `ui/dashboard-omnicomm.html` — рабочий стол по макету заказчика
- `ui/prototype-crm.html` — кликабельный прототип всех разделов (живые настройки)
- `ui/roadmap-crm.html` — дорожная карта проекта

## Платформа (продакшн-путь)
`liftplatform-omnicomm/` — миграции и роуты в конвенциях LiftPlatform (Next.js + PostgreSQL)
для форка и развёртывания; см. liftplatform-omnicomm/README.md и docs/TZ-COVERAGE.md.

## Документация (docs/)
- Анализ потребности — CRM Omnicomm
- Технический проект — кастомная CRM
- План адаптации LiftPlatform
- Gap-анализ Blueprint и адаптация
- Функции из демо вендора — адаптация в проект
- Рабочий документ разработки — полное описание функционала

Версия архива: 26.06.2026
